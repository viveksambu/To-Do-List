package com.Calculator.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //1. Create Objects
        EditText enNum1;
        EditText enNum2;
        Button btnAdd;
        Button btnMul;
        Button btnDiv;
        Button btnSub;
        TextView Result;

        //2. Binding UI with code
        enNum1 = findViewById(R.id.enNum1);
        enNum2 = findViewById(R.id.enNum2);
        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        Result = findViewById(R.id.Result);

        //3. Click Listeners
        btnAdd.setOnClickListener(v -> {
            try {
                double n1 = Double.parseDouble(enNum1.getText().toString());
                double n2 = Double.parseDouble(enNum2.getText().toString());
                double res = n1 + n2;
                Result.setText(String.valueOf(res));
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Please enter numbers", Toast.LENGTH_SHORT).show();
            }
        });

        btnSub.setOnClickListener(v -> {
            try {
                double n1 = Double.parseDouble(enNum1.getText().toString());
                double n2 = Double.parseDouble(enNum2.getText().toString());
                double res = n1 - n2;
                Result.setText(String.valueOf(res));
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Please enter numbers", Toast.LENGTH_SHORT).show();
            }
        });

        btnMul.setOnClickListener(v -> {
            try {
                double n1 = Double.parseDouble(enNum1.getText().toString());
                double n2 = Double.parseDouble(enNum2.getText().toString());
                double res = n1 * n2;
                Result.setText(String.valueOf(res));
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Please enter numbers", Toast.LENGTH_SHORT).show();
            }
        });

        btnDiv.setOnClickListener(v -> {
            try {
                double n1 = Double.parseDouble(enNum1.getText().toString());
                double n2 = Double.parseDouble(enNum2.getText().toString());
                if (n2 != 0) {
                    double res = n1 / n2;
                    Result.setText(String.valueOf(res));
                } else {
                    Result.setText("Error");
                    Toast.makeText(MainActivity.this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Please enter numbers", Toast.LENGTH_SHORT).show();
            }
        });

    }
}